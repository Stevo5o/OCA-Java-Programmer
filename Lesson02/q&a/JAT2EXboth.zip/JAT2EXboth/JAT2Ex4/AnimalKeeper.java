class AnimalKeeper
{
	
	public String feedAnimals(Animal animal)
	{
		return animal.feed();
	}
	
	public String preformTricks(Animal animal)
	{
		return animal.preformTrick();
	}
}

