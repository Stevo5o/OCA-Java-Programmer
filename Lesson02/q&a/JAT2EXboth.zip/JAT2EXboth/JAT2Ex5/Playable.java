interface Playable
{
	public String play(String piece);
}