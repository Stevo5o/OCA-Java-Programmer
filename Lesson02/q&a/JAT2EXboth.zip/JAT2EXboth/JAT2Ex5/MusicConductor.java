class MusicConductor 
{
	public String conductInstrument(Playable instrument)
	{
		return instrument.play(" The Four Seasons by Vivaldi");
	}
}