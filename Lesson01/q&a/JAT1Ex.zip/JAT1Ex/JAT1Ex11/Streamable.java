public interface Streamable
{
	public void streamVideo();
}